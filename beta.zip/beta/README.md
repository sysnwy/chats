# assistant
<img src="favicon.ico" alt="icon" />

Project `Web` chat with `AI` model for Chinese language version `zh-CN` after its old version using English `en-US`.
<br />Visit the deployed website here

# What we update 
- We changed and added Chinese language
- Adding and fixing error models
- New update now you can discuss with us on Whatsapp business

